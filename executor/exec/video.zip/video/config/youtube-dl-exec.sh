#!/bin/bash
if [ $# -lt 1 ];
then
  echo "USAGE: $0 URL"
  exit 1
fi
base_dir=$(dirname $0)

URL=$1
/usr/local/bin/youtube-dl --config-location $base_dir/youtube-dl.conf $URL
